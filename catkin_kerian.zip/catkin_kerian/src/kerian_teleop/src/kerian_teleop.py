#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from geometry_msgs.msg import Twist
import sys, select, termios, tty

msg = """
Control mrobot!
---------------------------
Moving around:
	w
      a s d
        x
q/z : increase/decrease max speeds by 10%
w/x : increase/decrease only linear speed by 10%
e/c : increase/decrease only angular speed by 10%
space key, k : force stop
anything else : stop smoothly

CTRL-C to quit
"""


          
controlBindings={
        'w':(1,0),
        'a':(0,1),
        'd':(0,-1),
        's':(-1,0),
	'q':(-1,0),
	'e':(0,-1),
}

def getKey():
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''

    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

speed = 0
turn = 0
XInc=0.05
THInc=0.05
XSPEED=0.8
ASPEED=1
last_th=0
last_x=0

LSpeed=0
RSpeed=0
DynamicWidth=0.285

def vels(speed,turn):
    return "currently:\tspeed %s\tturn %s " % (speed,turn)

if __name__=="__main__":
    settings = termios.tcgetattr(sys.stdin)
    
    rospy.init_node('kerian_teleop')
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=5)

    x = 0
    th = 0
    try:
        print(msg)
        print(vels(speed,turn))
        while(1):
            key = getKey()
            if key in controlBindings.keys():
                x += controlBindings[key][0]*XInc
                th += controlBindings[key][1]*THInc
    		if key == 'q':
                    x=0
                if key == 'e':
                    th=0
                LSpeed =  x - th*DynamicWidth;
		RSpeed =  x + th*DynamicWidth;
		if LSpeed >=XSPEED:
                    x=last_x
                    th=last_th
		if LSpeed <=-XSPEED:
		    x=last_x
		    th=last_th

		if RSpeed >=XSPEED:
		    x=last_x
		    th=last_th
		if RSpeed <=-XSPEED:
		    x=last_x
		    th=last_th

                print vels(x,th)
		last_x = x
		last_th=th
            # 停止键
            elif key == 'f' :
                x = 0
                th = 0
		print vels(x,th)
            else:
                if (key == '\x03'):
                    break
	     
            
            
            # 创建并发布twist消息
            twist = Twist()
            twist.linear.x = x; 
            twist.linear.y = 0; 
            twist.linear.z = 0
            twist.angular.x = 0; 
            twist.angular.y = 0; 
            twist.angular.z = th
            pub.publish(twist)

    except:
        print 'e'

    finally:
        twist = Twist()
        twist.linear.x = 0; twist.linear.y = 0; twist.linear.z = 0
        twist.angular.x = 0; twist.angular.y = 0; twist.angular.z = 0
        pub.publish(twist)

    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)

